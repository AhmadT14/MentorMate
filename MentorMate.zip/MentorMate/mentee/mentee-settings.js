document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  year.textContent = new Date().getFullYear();

  const settingsForm = document.getElementById("settingsForm");
  const deleteBtn = document.getElementById("deleteAccount");

  // Save changes
  settingsForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = {
      name: document.getElementById("name").value,
      field: document.getElementById("field").value,
      interests: document.getElementById("interests").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value
    };
    console.log("Mentee Settings saved:", data);
    alert("Settings updated successfully! (Mock)");
  });

  // Delete account
  deleteBtn.addEventListener("click", () => {
    if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      console.log("Mentee account deleted");
      alert("Account deleted (Mock)");
    }
  });
});
