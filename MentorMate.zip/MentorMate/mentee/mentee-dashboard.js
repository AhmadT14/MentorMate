// Mock mentors
const mentors = [
  {id:1, name:"Sara Ahmed", expertise:"Front-End", years:5, rating:4.8, avatar:"https://i.pravatar.cc/100?img=12", tags:["React","UI/UX","Accessibility"]},
  {id:2, name:"Omar Khaled", expertise:"Data Science", years:8, rating:4.9, avatar:"https://i.pravatar.cc/100?img=15", tags:["Python","Machine Learning","Pandas"]},
  {id:3, name:"Lina Nasser", expertise:"Product Design", years:6, rating:4.6, avatar:"https://i.pravatar.cc/100?img=20", tags:["Figma","Design Systems","Prototyping"]},
  {id:4, name:"Mohammad Ali", expertise:"Back-End", years:10, rating:4.7, avatar:"https://i.pravatar.cc/100?img=5", tags:["Node.js","Databases","Architecture"]},
  {id:5, name:"Rana Saeed", expertise:"Cybersecurity", years:7, rating:4.5, avatar:"https://i.pravatar.cc/100?img=31", tags:["OWASP","Network","Threat Modeling"]},
  {id:6, name:"Yousef Zain", expertise:"Mobile (Flutter)", years:4, rating:4.4, avatar:"https://i.pravatar.cc/100?img=7", tags:["Flutter","Dart","Play Store"]}
];

// Elements
const grid = document.getElementById('grid');
const emptyState = document.getElementById('emptyState');
const q = document.getElementById('q');
const expertise = document.getElementById('expertise');
const minYears = document.getElementById('minYears');
const sortBy = document.getElementById('sortBy');
const applyBtn = document.getElementById('apply');
const clearBtn = document.getElementById('clear');
const resetFromEmpty = document.getElementById('resetFromEmpty');
const resultCounter = document.getElementById('resultCounter');

const requestModalEl = document.getElementById('requestModal');
const requestModal = new bootstrap.Modal(requestModalEl);
const mentorIdInput = document.getElementById('mentorId');
const modalMentorName = document.getElementById('modalMentorName');
const requestForm = document.getElementById('requestForm');
const toast = new bootstrap.Toast(document.getElementById('toast'));
const toastMsg = document.getElementById('toastMsg');

const requestsTable = document.getElementById("requestsTable");
const notifList = document.getElementById("notifList");
const notifBadge = document.getElementById("notifBadge");

// Populate expertise options
(function initExpertise(){
  const set = new Set(mentors.map(m=>m.expertise));
  [...set].sort().forEach(x=>{
    const opt = document.createElement('option');
    opt.value = x; opt.textContent = x;
    expertise.appendChild(opt);
  });
})();

// Render mentors
function render(list){
  grid.innerHTML = '';
  if(!list.length){
    emptyState.classList.remove('d-none');
    resultCounter.textContent = 'Showing 0 mentors';
    return;
  }
  emptyState.classList.add('d-none');
  resultCounter.textContent = `Showing ${list.length} mentor${list.length>1?'s':''}`;

  list.forEach((m, idx)=>{
    const col = document.createElement('div');
    col.className = 'col-12 col-md-6 col-lg-4';
    col.innerHTML = `
      <div class="mentor-card h-100">
        <div class="p-3 d-flex align-items-center">
          <img src="${m.avatar}" class="avatar-sm me-3" alt="${m.name}">
          <div>
            <div class="d-flex align-items-center gap-2">
              <h6 class="mb-0">${m.name}</h6>
              <span class="badge badge-soft rounded-pill">${m.expertise}</span>
            </div>
            <div class="small text-muted mt-1">
              <span class="me-2"><i class="bi bi-briefcase me-1"></i>${m.years} yrs</span>
              <span class="rating"><i class="bi bi-star-fill"></i> ${m.rating.toFixed(1)}</span>
            </div>
          </div>
        </div>
        <div class="px-3 pb-3">
          <div class="d-flex flex-wrap gap-2 mb-3">
            ${m.tags.map(t=>`<span class="badge text-bg-light">${t}</span>`).join('')}
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-primary flex-fill" data-id="${m.id}">
              <i class="bi bi-calendar2-check me-1"></i> Request Session
            </button>
            <button class="btn btn-outline-primary" title="View profile">
              <i class="bi bi-person-lines-fill"></i>
            </button>
          </div>
        </div>
      </div>`;
    grid.appendChild(col);

    setTimeout(()=> col.querySelector('.mentor-card').classList.add('show'), 70*idx);
  });

  // Bind request buttons
  grid.querySelectorAll('.btn.btn-primary').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = +btn.getAttribute('data-id');
      const m = mentors.find(x=>x.id===id);
      mentorIdInput.value = id;
      modalMentorName.textContent = m.name;
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth()+1).padStart(2,'0');
      const dd = String(today.getDate()).padStart(2,'0');
      document.getElementById('reqDate').min = `${yyyy}-${mm}-${dd}`;
      document.getElementById('reqDate').value = `${yyyy}-${mm}-${dd}`;
      document.getElementById('reqTime').value = "15:00";
      document.getElementById('reqType').value = "online";
      document.getElementById('reqMsg').value = "";
      requestModal.show();
    });
  });
}

// Filtering
function applyFilters(){
  const term = q.value.trim().toLowerCase();
  const exp = expertise.value;
  const min = parseInt(minYears.value, 10) || 0;
  const sort = sortBy.value;

  let list = mentors.filter(m=>{
    const byTerm = !term || [m.name, m.expertise, ...(m.tags||[])].join(' ').toLowerCase().includes(term);
    const byExp = !exp || m.expertise === exp;
    const byYears = m.years >= min;
    return byTerm && byExp && byYears;
  });

  switch(sort){
    case 'rating': list.sort((a,b)=> b.rating - a.rating); break;
    case 'experience': list.sort((a,b)=> b.years - a.years); break;
    case 'name': list.sort((a,b)=> a.name.localeCompare(b.name)); break;
    default: list.sort((a,b)=> (b.rating*10 + b.years) - (a.rating*10 + a.years));
  }

  render(list);
}

// Requests handling
function loadRequests(){
  const key = 'mm_requests';
  const data = JSON.parse(localStorage.getItem(key)||'[]');
  requestsTable.innerHTML = '';
  if(!data.length){
    requestsTable.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No requests yet</td></tr>`;
    return;
  }
  data.forEach(r=>{
    const m = mentors.find(x=>x.id==r.mentorId);
    requestsTable.innerHTML += `
      <tr>
        <td>${m?m.name:"Unknown"}</td>
        <td>${r.date}</td>
        <td>${r.time}</td>
        <td>${r.type}</td>
        <td><span class="badge bg-warning">Pending</span></td>
      </tr>`;
  });
}

// Notifications mock
function loadNotifs(){
  const notifs = JSON.parse(localStorage.getItem("mm_notifs")||"[]");
  notifList.innerHTML = "";
  if(!notifs.length){
    notifList.innerHTML = `<div class="text-center text-muted p-3">No notifications</div>`;
    notifBadge.classList.add("d-none");
    return;
  }
  notifs.forEach(n=>{
    const item = document.createElement("a");
    item.className="list-group-item list-group-item-action";
    item.innerHTML = `<i class="bi bi-info-circle me-2"></i>${n}`;
    notifList.appendChild(item);
  });
  notifBadge.textContent = notifs.length;
  notifBadge.classList.remove("d-none");
}

// Events
applyBtn.addEventListener('click', applyFilters);
clearBtn.addEventListener('click', ()=>{
  q.value=""; expertise.value=""; minYears.value="0"; sortBy.value="featured"; applyFilters();
});
resetFromEmpty.addEventListener('click', ()=> clearBtn.click());

requestForm.addEventListener('submit',(e)=>{
  e.preventDefault();
  const payload = {
    mentorId: mentorIdInput.value,
    date: document.getElementById('reqDate').value,
    time: document.getElementById('reqTime').value,
    type: document.getElementById('reqType').value,
    msg: document.getElementById('reqMsg').value
  };
  const key = 'mm_requests';
  const existing = JSON.parse(localStorage.getItem(key)||'[]');
  existing.push(payload);
  localStorage.setItem(key, JSON.stringify(existing));
  requestModal.hide();
  toastMsg.textContent = "Request sent successfully 🎉";
  toast.show();

  // push notif
  let notifs = JSON.parse(localStorage.getItem("mm_notifs")||"[]");
  notifs.push(`Your request to mentor #${payload.mentorId} is pending`);
  localStorage.setItem("mm_notifs", JSON.stringify(notifs));

  loadRequests();
  loadNotifs();
});

document.getElementById("markAllRead").addEventListener("click", ()=>{
  localStorage.setItem("mm_notifs","[]");
  loadNotifs();
});

// Init
document.getElementById('year').textContent = new Date().getFullYear();
applyFilters();
loadRequests();
loadNotifs();
