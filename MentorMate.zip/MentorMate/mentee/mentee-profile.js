
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("year").textContent = new Date().getFullYear();

  // Mock mentee data
  const mentee = {
    name: "Alaa Abu Musa",
    study: "Computer Engineering Student",
    field: "AI & Web Development",
    sessions: 3,
    bio: "Passionate learner looking to grow in tech fields, focusing on AI and Web Development.",
    interests: ["UI/UX", "Machine Learning", "Fullstack Development"],
  };

  document.getElementById("menteeName").textContent = mentee.name;
  document.getElementById("menteeStudy").textContent = mentee.study;
  document.getElementById("menteeField").textContent = mentee.field;
  document.getElementById("menteeSessions").textContent = mentee.sessions + " Sessions";
  document.getElementById("menteeBio").textContent = mentee.bio;

  const interestsContainer = document.getElementById("menteeInterests");
  interestsContainer.innerHTML = "";
  mentee.interests.forEach((interest) => {
    const badge = document.createElement("span");
    badge.className = "badge bg-info text-dark";
    badge.textContent = interest;
    interestsContainer.appendChild(badge);
  });
});
