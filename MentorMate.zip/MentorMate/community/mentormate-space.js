const postsFeed = document.getElementById('postsFeed');
const postForm = document.getElementById('postForm');
const postTitle = document.getElementById('postTitle');
const postContent = document.getElementById('postContent');
const postType = document.getElementById('postType');

let posts = JSON.parse(localStorage.getItem('mentor_space_posts') || '[]');

// Demo post
if (posts.length === 0) {
  posts = [
    {
      id: Date.now(),
      user: { name: "Sara Ahmed", role: "Mentee", avatar: "https://i.pravatar.cc/50?img=5" },
      title: "Best way to learn React?",
      content: "I'm new to React and looking for the best resources to learn. Any advice?",
      type: "question",
      comments: [
        { name: "Omar Mentor", text: "Try the official React docs!", replies: [] }
      ],
      date: new Date().toISOString()
    }
  ];
  savePosts();
}

function savePosts() {
  localStorage.setItem('mentor_space_posts', JSON.stringify(posts));
}

// Recursive render for comments
function renderComments(comments, postId, level = 0) {
  return comments.map((c, index) => `
    <div class="comment ms-${level * 4}">
      <img src="https://i.pravatar.cc/40?u=${c.name}" class="avatar-sm">
      <div>
        <p><strong>${c.name}:</strong> ${c.text}</p>
        <button class="btn btn-link btn-sm p-0" onclick="showReplyBox(${postId}, [${level},${index}])">Reply</button>
        <div id="reply-box-${postId}-${level}-${index}" class="reply-box d-none">
          <input type="text" id="reply-input-${postId}-${level}-${index}" class="form-control form-control-sm mb-1" placeholder="Write a reply...">
          <button class="btn btn-sm btn-outline-primary" onclick="addReply(${postId}, [${level},${index}])">Send</button>
        </div>
        <div class="replies">
          ${renderComments(c.replies || [], postId, level + 1)}
        </div>
      </div>
    </div>
  `).join('');
}

function renderPosts() {
  postsFeed.innerHTML = '';
  posts.slice().reverse().forEach(post => {
    const postDiv = document.createElement('div');
    postDiv.className = 'post-card';
    postDiv.innerHTML = `
      <div class="post-header">
        <img src="${post.user.avatar}" class="avatar-sm">
        <div>
          <h6>${post.user.name} <span class="badge bg-light text-dark ms-1">${post.user.role}</span></h6>
          <div class="post-meta">${new Date(post.date).toLocaleString()} - ${post.type}</div>
        </div>
      </div>
      <div class="post-body">
        <strong>${post.title}</strong>
        <p class="mt-1 mb-0">${post.content}</p>
      </div>
      <div class="post-actions d-flex gap-2">
        <button class="btn btn-outline-secondary btn-sm" onclick="toggleComments(${post.id})">
          <i class="bi bi-chat"></i> Comments (${post.comments.length})
        </button>
      </div>
      <div id="comments-${post.id}" class="comments d-none">
        ${renderComments(post.comments, post.id)}
        <div class="d-flex gap-2 mt-2">
          <input type="text" id="comment-input-${post.id}" class="form-control form-control-sm" placeholder="Write a comment...">
          <button class="btn btn-sm btn-primary" onclick="addComment(${post.id})">Post</button>
        </div>
      </div>
    `;
    postsFeed.appendChild(postDiv);
  });
}

function toggleComments(postId) {
  document.getElementById(`comments-${postId}`).classList.toggle('d-none');
}

function addComment(postId) {
  const input = document.getElementById(`comment-input-${postId}`);
  const text = input.value.trim();
  if (!text) return;
  const post = posts.find(p => p.id === postId);
  post.comments.push({ name: "Alaa", text, replies: [] });
  savePosts();
  renderPosts();
}

function showReplyBox(postId, path) {
  document.getElementById(`reply-box-${postId}-${path.join('-')}`).classList.toggle('d-none');
}

function addReply(postId, path) {
  const input = document.getElementById(`reply-input-${postId}-${path.join('-')}`);
  const text = input.value.trim();
  if (!text) return;

  let post = posts.find(p => p.id === postId);
  let comment = post.comments[path[1]];

  // traverse nested replies
  for (let i = 2; i < path.length; i++) {
    comment = comment.replies[path[i]];
  }

  comment.replies.push({ name: "Alaa", text, replies: [] });
  savePosts();
  renderPosts();
}

postForm.addEventListener('submit', e => {
  e.preventDefault();
  const newPost = {
    id: Date.now(),
    user: { name: "Alaa", role: "Mentee", avatar: "https://i.pravatar.cc/50?u=alaa" },
    title: postTitle.value,
    content: postContent.value,
    type: postType.value,
    comments: [],
    date: new Date().toISOString()
  };
  posts.push(newPost);
  savePosts();
  renderPosts();
  postForm.reset();
  bootstrap.Modal.getInstance(document.getElementById('createPostModal')).hide();
});

// Initial render
renderPosts();
