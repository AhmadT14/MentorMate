// DOM Elements
const requestsListEl = document.getElementById("requestsList");
const menteesListEl = document.getElementById("menteesList");
const notifListEl = document.getElementById("notifList");
const notifBadgeEl = document.getElementById("notifBadge");
const markAllReadBtn = document.getElementById("markAllRead");

// Data
let requests = [
  { id: 1, name: "Ali", msg: "I'd love to learn React from you!" },
  { id: 2, name: "Lina", msg: "Can you mentor me in Python?" },
];

let mentees = [];
let notifications = [];

// Init
document.getElementById("year").textContent = new Date().getFullYear();
renderRequests();
renderMentees();
updateNotifUI();

// ---------------- Requests ----------------
function renderRequests() {
  requestsListEl.innerHTML = "";
  if (requests.length === 0) {
    requestsListEl.innerHTML = "<p class='text-muted'>No new requests.</p>";
    return;
  }
  requests.forEach((r) => {
    const div = document.createElement("div");
    div.className =
      "d-flex justify-content-between align-items-start border-bottom py-2";
    div.innerHTML = `
      <div>
        <div class="fw-semibold">${r.name}</div>
        <small class="text-muted">${r.msg}</small>
      </div>
      <div>
        <button class="btn btn-sm btn-success me-1" onclick="acceptRequest(${r.id})"><i class="bi bi-check"></i></button>
        <button class="btn btn-sm btn-danger" onclick="rejectRequest(${r.id})"><i class="bi bi-x"></i></button>
      </div>`;
    requestsListEl.appendChild(div);
  });
}

function acceptRequest(id) {
  const req = requests.find((r) => r.id === id);
  if (!req) return;
  requests = requests.filter((r) => r.id !== id);
  mentees.push(req);
  renderRequests();
  renderMentees();
  showToast(`${req.name} is now connected!`);
  addNotification(`${req.name} connected with you.`);
}

function rejectRequest(id) {
  const req = requests.find((r) => r.id === id);
  requests = requests.filter((r) => r.id !== id);
  renderRequests();
  showToast(`Rejected ${req?.name}'s request`);
}

// ---------------- Mentees ----------------
function renderMentees() {
  menteesListEl.innerHTML = "";
  if (mentees.length === 0) {
    menteesListEl.innerHTML = "<p class='text-muted'>No connections yet.</p>";
    return;
  }
  mentees.forEach((m) => {
    const div = document.createElement("div");
    div.className = "border-bottom py-2";
    div.innerHTML = `<div class="fw-semibold">${m.name}</div>`;
    menteesListEl.appendChild(div);
  });
}

// ---------------- Notifications ----------------
function addNotification(msg) {
  notifications.unshift({ msg, read: false });
  updateNotifUI();
}
function updateNotifUI() {
  notifListEl.innerHTML = "";
  let unread = 0;
  notifications.forEach((n) => {
    if (!n.read) unread++;
    const item = document.createElement("a");
    item.className = "list-group-item list-group-item-action";
    item.href = "#";
    item.textContent = n.msg;
    notifListEl.appendChild(item);
  });
  notifBadgeEl.textContent = unread;
  notifBadgeEl.classList.toggle("d-none", unread === 0);
}
markAllReadBtn.addEventListener("click", () => {
  notifications.forEach((n) => (n.read = true));
  updateNotifUI();
});

// ---------------- Toast ----------------
function showToast(msg) {
  const toastEl = document.createElement("div");
  toastEl.className =
    "toast align-items-center text-bg-dark border-0 position-fixed bottom-0 end-0 m-3";
  toastEl.role = "alert";
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${msg}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>`;
  document.body.appendChild(toastEl);
  const bsToast = new bootstrap.Toast(toastEl, { delay: 2500 });
  bsToast.show();
  toastEl.addEventListener("hidden.bs.toast", () => toastEl.remove());
}
