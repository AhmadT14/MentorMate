document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  year.textContent = new Date().getFullYear();

  const settingsForm = document.getElementById("settingsForm");
  const deleteBtn = document.getElementById("deleteAccount");

  // Save changes
  settingsForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = {
      name: document.getElementById("name").value,
      expertise: document.getElementById("expertise").value,
      years: document.getElementById("years").value,
      linkedin: document.getElementById("linkedin").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value
    };
    console.log("Settings saved:", data);
    alert("Settings updated successfully! (Mock)");
  });

  // Delete account
  deleteBtn.addEventListener("click", () => {
    if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      console.log("Account deleted");
      alert("Account deleted (Mock)");
    }
  });
});
