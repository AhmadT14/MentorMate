document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("year").textContent = new Date().getFullYear();

  // Mock: load mentor data (replace with API later)
  const mentor = {
    name: "Omar Khaled",
    expertise: "Data Science",
    years: 8,
    rating: 4.9,
    bio: "Passionate Data Scientist with 8+ years of experience in Machine Learning and AI.",
    skills: ["Python", "Machine Learning", "Pandas", "Deep Learning"],
  };

  document.getElementById("mentorName").textContent = mentor.name;
  document.getElementById("mentorExpertise").textContent =
    mentor.expertise + " Mentor";
  document.getElementById("mentorYears").textContent = mentor.years + " Years";
  document.getElementById("mentorRating").textContent = mentor.rating;
  document.getElementById("mentorBio").textContent = mentor.bio;

  const skillsContainer = document.getElementById("mentorSkills");
  skillsContainer.innerHTML = "";
  mentor.skills.forEach((skill) => {
    const badge = document.createElement("span");
    badge.className = "badge bg-primary";
    badge.textContent = skill;
    skillsContainer.appendChild(badge);
  });
});
