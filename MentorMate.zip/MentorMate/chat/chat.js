// Mock: current user (role mentee/mentor)
const currentUser = JSON.parse(localStorage.getItem("mm_user") || '{"id":"u1","name":"Alaa (Mentee)","role":"mentee","avatar":"https://i.pravatar.cc/100?img=32"}');

// Demo conversations
const chats = [
  {id:"c1", name:"Sara Ahmed", avatar:"", messages:[
    {from:"c1", text:"Hello, how can I help?", time:"10:00"},
    {from:"u1", text:"I want to improve my React skills.", time:"10:02"}
  ]},
  {id:"c2", name:"Omar Khaled", avatar:"", messages:[
    {from:"c2", text:"Data Science is fun!", time:"11:00"}
  ]}
];

let activeChat = null;

const els = {
  chatList: document.getElementById("chatList"),
  chatMessages: document.getElementById("chatMessages"),
  chatHeader: document.getElementById("chatHeader"),
  chatForm: document.getElementById("chatForm"),
  chatText: document.getElementById("chatText"),
  userName: document.getElementById("userName"),
  avatar: document.getElementById("avatar"),
};

els.userName.textContent = currentUser.name;
els.avatar.src = currentUser.avatar;



// Dashboard link logic
const dashboardLink = document.getElementById("dashboardLink");
if(currentUser?.role === "mentee"){
  dashboardLink.href = "mentee-dashboard.html";
} else if(currentUser?.role === "mentor"){
  dashboardLink.href = "mentor-dashboard.html";
} else {
  // fallback: لو مش مسجل، يرجع للـ login
  dashboardLink.href = "login.html";
}


function renderChatList(){
  els.chatList.innerHTML = "";
  chats.forEach(c=>{
    const item = document.createElement("a");
    item.href="#";
    item.className="list-group-item list-group-item-action d-flex align-items-center gap-2";
    item.innerHTML = `<img src="${c.avatar}" class="avatar-sm"><div>${c.name}</div>`;
    item.onclick = (e)=>{ e.preventDefault(); openChat(c.id); };
    els.chatList.appendChild(item);
  });
}

function renderMessages(chat){
  els.chatMessages.innerHTML = "";
  chat.messages.forEach(m=>{
    const div = document.createElement("div");
    div.className = "message " + (m.from===currentUser.id?"sent":"received");
    div.innerHTML = `${m.text}<small>${m.time}</small>`;
    els.chatMessages.appendChild(div);
  });
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
}

function openChat(id){
  activeChat = chats.find(c=>c.id===id);
  els.chatHeader.textContent = activeChat.name;
  renderMessages(activeChat);
}

els.chatForm.addEventListener("submit", (e)=>{
  e.preventDefault();
  if(!activeChat) return;
  const text = els.chatText.value.trim();
  if(!text) return;
  const msg = {from:currentUser.id, text, time:new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})};
  activeChat.messages.push(msg);
  renderMessages(activeChat);
  els.chatText.value="";
});




// Init
renderChatList();
